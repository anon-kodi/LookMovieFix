# plugin.video.lookmovietomb
Forked from mbebe's LookMovie2 addon for Kodi
Im fixing this addon for myself and my family, feel free to use it.
